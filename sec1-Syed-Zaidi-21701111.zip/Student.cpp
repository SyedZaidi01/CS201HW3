
#include <iostream>
#include "Student.h"
#include <string>

using namespace std;

  Student::Student(){

    }

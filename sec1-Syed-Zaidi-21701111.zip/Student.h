#include <string>
#include <iostream>
#pragma once


using namespace std;

class Student{

public:
    Student ();
    //int getId();
    //string getName();






};
